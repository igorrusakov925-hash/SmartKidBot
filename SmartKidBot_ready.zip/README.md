SmartKidBot — простой Telegram-бот (MVP) для детей
==================================================

Это готовый к загрузке ZIP-пакет для облачного хостинга (Render.com или аналог).
Бот написан для работы на Python и использует OpenAI для умных ответов.
В этой сборке мы минимизировали зависимости и отказались от компилируемых Rust-модулей.

Особенности MVP:
- Регистрация ребёнка (имя, возраст)
- Команды: /start, /mission, /study, /wallet, /mood, /parent
- Хранение профилей в JSON (users.json)
- Простая фильтрация запрещённых слов (локальный список)
- Интеграция с OpenAI (используется ChatCompletion API)
- Русский язык, спокойный нейтральный стиль общения
- Лёгкие зависимости: aiogram v2, openai, python-dotenv

Как использовать (Render / любой cloud с поддержкой Python):
1) Разархивируй пакет или загрузи ZIP в панель хостинга (Render supports ZIP upload).
2) Добавь переменные окружения (Environment):
   - TELEGRAM_TOKEN  (токен от BotFather)
   - OPENAI_API_KEY  (ключ OpenAI, начинается с sk-...)
   - PARENT_PIN      (например 4321)
3) Build command:  pip install -r requirements.txt
4) Start command:  python bot.py
5) После запуска напиши боту в Telegram /start

Локальный запуск (Windows):
- Убедись, что Python 3.10+ установлен
- Создай файл .env рядом с bot.py (или используй .env.example)
  TELEGRAM_TOKEN=...
  OPENAI_API_KEY=...
  PARENT_PIN=4321
- Установи зависимости: python -m pip install -r requirements.txt
- Запусти: python bot.py

Важно:
- Не публикуй свои секреты (OPENAI_API_KEY и TELEGRAM_TOKEN).
- Если у тебя нет доступа к GPT-4, в коде есть автоматический fallback на gpt-3.5-turbo.
