import os
import json
import logging
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, executor, types
import openai
from pathlib import Path

# Load environment
load_dotenv()
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
PARENT_PIN = os.getenv('PARENT_PIN', '4321')

if not TELEGRAM_TOKEN or not OPENAI_API_KEY:
    print("ERROR: TELEGRAM_TOKEN and OPENAI_API_KEY must be set in environment or .env")
    raise SystemExit(1)

# OpenAI setup
openai.api_key = OPENAI_API_KEY

# Bot setup
logging.basicConfig(level=logging.INFO)
bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher(bot)

# Simple JSON storage for MVP
DATA_FILE = Path('users.json')
if not DATA_FILE.exists():
    DATA_FILE.write_text(json.dumps({}))

def load_users():
    try:
        return json.loads(DATA_FILE.read_text())
    except Exception:
        return {}

def save_users(data):
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2))

# Simple banned words list (expand as needed)
BANNED = ['плохое_слово1','плохое_слово2']

# Helper to call OpenAI with fallback
def ask_openai(prompt, max_tokens=300, temp=0.7):
    try:
        resp = openai.ChatCompletion.create(
            model='gpt-4',
            messages=[
                {'role':'system', 'content': 'Ты спокойный и нейтральный детский помощник. Отвечай на русском языке, простыми словами.'},
                {'role':'user', 'content': prompt}
            ],
            max_tokens=max_tokens,
            temperature=temp
        )
        return resp['choices'][0]['message']['content']
    except Exception:
        try:
            resp = openai.ChatCompletion.create(
                model='gpt-3.5-turbo',
                messages=[
                    {'role':'system', 'content': 'Ты спокойный и нейтральный детский помощник. Отвечай на русском языке, простыми словами.'},
                    {'role':'user', 'content': prompt}
                ],
                max_tokens=max_tokens,
                temperature=temp
            )
            return resp['choices'][0]['message']['content']
        except Exception:
            logging.exception('OpenAI error')
            return 'Извини, сейчас я не могу подключиться к ИИ. Попробуй позже.'

# Command handlers
@dp.message_handler(commands=['start'])
async def cmd_start(message: types.Message):
    users = load_users()
    uid = str(message.from_user.id)
    if uid in users and users[uid].get('name'):
        name = users[uid].get('name')
        await message.answer(f'Привет, {name}! Я SmartKidBot — твой помощник. Напиши /mission чтобы получить задание дня.')
        return
    await message.answer('Привет! Как тебя зовут?')
    users[uid] = {'step':'ask_name'}
    save_users(users)

@dp.message_handler(commands=['mission'])
async def cmd_mission(message: types.Message):
    users = load_users()
    uid = str(message.from_user.id)
    age = users.get(uid, {}).get('age', 10)
    if age <=8:
        mission = 'Нарисуй сегодня свою семью ❤️'
    elif age <=11:
        mission = 'Придумай и запиши три добрых дела на день 🌞'
    else:
        mission = 'Сделай мини-проект: опиши, как сэкономить на мечту 💰'
    await message.answer('📋 Твоя миссия дня:\n' + mission)

@dp.message_handler(commands=['study'])
async def cmd_study(message: types.Message):
    await message.answer('Напиши кратко, с чем нужна помощь (например: "помоги с дробями")')
    users = load_users()
    uid = str(message.from_user.id)
    users[uid] = users.get(uid, {})
    users[uid]['step'] = 'study'
    save_users(users)

@dp.message_handler(commands=['wallet'])
def cmd_wallet(message: types.Message):
    # simple synchronous reply to tell user to type goal
    import asyncio
    asyncio.create_task(message.answer('Расскажи, на что хочешь накопить, и я помогу составить план!'))
    users = load_users()
    uid = str(message.from_user.id)
    users[uid] = users.get(uid, {})
    users[uid]['step'] = 'wallet'
    save_users(users)

@dp.message_handler(commands=['mood'])
async def cmd_mood(message: types.Message):
    await message.answer('Как ты себя чувствуешь сегодня? (хорошо/грусть/злой/устал)')
    users = load_users()
    uid = str(message.from_user.id)
    users[uid] = users.get(uid, {})
    users[uid]['step'] = 'mood'
    save_users(users)

@dp.message_handler(commands=['parent'])
async def cmd_parent(message: types.Message):
    await message.answer('Введите PIN для родительского режима:')
    users = load_users()
    uid = str(message.from_user.id)
    users[uid] = users.get(uid, {})
    users[uid]['step'] = 'parent_pin'
    save_users(users)

@dp.message_handler()
async def all_messages(message: types.Message):
    users = load_users()
    uid = str(message.from_user.id)
    text = message.text.strip()

    # check banned words
    low = text.lower()
    for b in BANNED:
        if b in low:
            await message.answer('Извини, я не могу обсуждать такие темы. Давай поговорим о хобби или учебе.')
            return

    state = users.get(uid, {}).get('step')
    if state == 'ask_name':
        users[uid]['name'] = text
        users[uid]['step'] = 'ask_age'
        save_users(users)
        await message.answer(f'Приятно познакомиться, {text}! Сколько тебе лет?')
        return
    if state == 'ask_age':
        try:
            age = int(text)
        except:
            await message.answer('Пожалуйста, напиши число — твой возраст.')
            return
        users[uid]['age'] = age
        users[uid]['step'] = None
        save_users(users)
        await message.answer('Готово! Напиши /mission, чтобы получить задание дня.')
        return
    if state == 'study':
        # call OpenAI for study help
        await message.answer('Секунду, думаю...')
        prompt = f'Объясни ребёнку {users.get(uid, {}).get("age", 10)} лет тему: {text}. Объясни простыми шагами и приведи пример.'
        out = ask_openai(prompt, max_tokens=300)
        await message.answer(out)
        users[uid]['step'] = None
        save_users(users)
        return
    if state == 'wallet':
        await message.answer('Держи план:')
        prompt = f'Ребёнок {users.get(uid, {}).get("age",10)} лет хочет накопить: {text}. Составь простой план экономии и 3 способы заработать или сэкономить.'
        out = ask_openai(prompt, max_tokens=200)
        await message.answer(out)
        users[uid]['step'] = None
        save_users(users)
        return
    if state == 'mood':
        if 'гру' in low or 'плохо' in low or 'уста' in low:
            await message.answer('Мне жаль, что тебе грустно. Хочешь дыхательное упражнение? (да/нет)')
            users[uid]['step'] = 'mood_help'
            save_users(users)
            return
        else:
            await message.answer('Рад за тебя! Продолжай в том же духе 😊')
            users[uid]['step'] = None
            save_users(users)
            return
    if state == 'mood_help':
        if text.lower().startswith('да'):
            await message.answer('Хорошо. Вдох 4 сек, задержка 4 сек, выдох 4 сек. Повтори 3 раза.')
        else:
            await message.answer('Хорошо. Если захочешь — напиши /mood снова.')
        users[uid]['step'] = None
        save_users(users)
        return
    if state == 'parent_pin':
        if text == PARENT_PIN:
            users[uid]['parent_mode'] = True
            save_users(users)
            await message.answer('Режим родителя включён. (В MVP статистика пока не реализована)')
        else:
            await message.answer('Неверный PIN.')
        users[uid]['step'] = None
        save_users(users)
        return

    # default small-talk via OpenAI
    await message.answer('Думаю...')
    prompt = f'Отвечай ребёнку {users.get(uid, {}).get("age",10)} лет на русском простыми словами: {text}'
    out = ask_openai(prompt, max_tokens=200)
    await message.answer(out)

if __name__ == '__main__':
    print('Bot is starting...')
    executor.start_polling(dp, skip_updates=True)
